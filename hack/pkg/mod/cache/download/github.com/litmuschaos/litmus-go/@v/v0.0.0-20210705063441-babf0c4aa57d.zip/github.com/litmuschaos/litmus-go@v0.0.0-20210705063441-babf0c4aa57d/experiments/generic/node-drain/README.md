## Experiment Metadata

<table>
<tr>
<th> Name </th>
<th> Description </th>
<th> Documentation Link </th>
</tr>
<tr>
 <td> Node Drain </td>
 <td> This experiment drains the node where application pod is running and verifies if it is scheduled on another available node. </td>
 <td>  <a href="https://docs.litmuschaos.io/docs/node-drain/"> Here </a> </td>
 </tr>
 </table>
