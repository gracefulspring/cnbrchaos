## Experiment Metadata

<table>
<tr>
<th> Name </th>
<th> Description </th>
<th> Documentation Link </th>
</tr>
<tr>
 <td> Pod Memory Hog Exec </td>
 <td> This experiment causes Memory resource consumption on specified application containers by using dd command which will used to consume memory of the application container for certain duration of time. It can test the application's resilience to potential slowness/unavailability of some replicas due to high Memory load.</td>
 <td>  <a href="https://docs.litmuschaos.io/docs/pod-memory-hog-exec/"> Here </a> </td>
 </tr>
</table>