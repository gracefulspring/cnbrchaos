## Experiment Metadata

<table>
<tr>
<th> Name </th>
<th> Description </th>
<th> Documentation Link </th>
</tr>
<tr>
 <td> Pod Autoscaler</td>
 <td> Scale the deployment replicas to check the autoscaling capability. </td>
 <td>  <a href="https://docs.litmuschaos.io/docs/pod-autoscaler/"> Here </a> </td>
 </tr>
 </table>