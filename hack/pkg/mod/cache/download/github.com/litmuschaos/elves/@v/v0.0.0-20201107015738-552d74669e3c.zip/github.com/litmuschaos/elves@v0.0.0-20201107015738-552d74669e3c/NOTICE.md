The source code developed for the LitmusChaos Project is licensed under Apache 2.0. 

However, the LitmusChaos project contains unmodified subcomponents from other Open Source Projects with separate copyright notices and license terms. 

Your use of the source code for these subcomponents is subject to the terms and conditions as defined by those source projects.
